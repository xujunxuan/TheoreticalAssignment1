/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package theoreticalassignment1;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import jxl.*;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.*;
import org.jsoup.select.*;


 /*
 * @author Pinckney Emiya
 *
 *File->html->doc->Elements->Element->text->Label->xls
 */
public class MainOutPut {
    public static void processScoreTable(File input)
    {
        /*
        Try to read the html
        */
        //File keyA = new File("233.html");
        Document doc = null;
        try {
            doc = Jsoup.parse(input,"gb2312");
        } catch (IOException ex) {
            Logger.getLogger(MainOutPut.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        int scoreL = 0,markL = 0,gpaL = 0;
        Elements courses=doc.select("tr");
        //Elements course=courses.select("td");
        Elements title=doc.select("tr").select("th");
        String titleGet[]=new String[100];
        String scoreGet[]=new String[100];
        String gpaGet[]=new String[100];
       //Element test=course.get(0);
        //Label titleLabel[]=new Label[10];

        
        
        
        try {
            //Set File
            File outputFile = new File("result.xls");
            
            WritableWorkbook workbook = Workbook.createWorkbook(outputFile);
            WritableSheet sheet = workbook.createSheet("Score",0);
            
            //Output
            for(int i = 0;i<title.size();i++)
            {
            titleGet[i]=title.get(i).text();
                
            Label outLabel=new Label(i,0,titleGet[i]);
            sheet.addCell(outLabel);
            //System.out.println(titleGet[i]);
            }
            Label titleLabel=new Label(title.size(),0,"GPA");
            sheet.addCell(titleLabel);
            for(int i=0;i<title.size();i++)
            {
                if (titleGet[i].equals("成绩"))
                {
                    scoreL=i;
                    System.out.println(scoreL);
                } 
                else if(titleGet[i].equals("学分"))
                {
                    markL=i;
                    System.out.println(markL);
                }
            }
            gpaL=title.size();

            for (int i=0;i<courses.size();i++)
            {
                /*for(int j=0;j<title.size();j++)
                {
                    //courseGet[i][j]=course.get(i+j*title.size()).text();
                    //Label outLabel=new Label(i,j+1,courseGet[i][j]);
                    //sheet.addCell(outLabel);
                }*/
                Elements course=courses.get(i).select("td");
                for(int j=0;j<course.size();j++)
                {
                   Label outLabel=new Label(j,i+1,course.get(j).text());
                   sheet.addCell(outLabel);
                }
                //Label outLabel=new Label(tds,trs,course.get(i).text());
                
               
            }
            
            
            //Save to array
            int maxC=courses.size();
            int courseNum[]=new int[maxC];
            double courseMark[]=new double[maxC];
            double courseScore[]=new double[maxC];
            double courseGpa[]=new double[maxC];
            
            for (int i=1;i<maxC;i++)
            {
                courseNum[i]=i;
                //int markF=markL+i*title.size();
                //int scoreF=scoreL+i*title.size();
                Elements course=courses.get(i).select("td");
                
                String temp=course.get(markL).text();
                if (!"".equals(temp))
                {
                    courseMark[i]=Double.valueOf(temp);
                }
                else
                {
                    courseMark[i]=0;
                }
                
                if (!"".equals(course.get(scoreL).text()))
                {
                    temp=course.get(scoreL).text();
                    //System.out.println(temp);
                    courseScore[i]=Double.valueOf(temp);
                    if(courseScore[i]>=90)
                    {
                        courseGpa[i]=4.0;
                    }
                    else if(courseScore[i]>=85)
                    {   
                        courseGpa[i]=3.7;
                    }
                    else if(courseScore[i]>=82)
                    {
                        courseGpa[i]=3.3;
                    }
                    else if(courseScore[i]>=78)
                    {
                        courseGpa[i]=3.0;
                    }
                    else if(courseScore[i]>=75)
                    {
                        courseGpa[i]=2.7;
                    }
                    else if(courseScore[i]>=72)
                    {
                        courseGpa[i]=2.3;
                    }
                    else if(courseScore[i]>=68)
                    {
                        courseGpa[i]=2.0;
                    }
                    else if(courseScore[i]>=64)
                    {
                        courseGpa[i]=1.5;
                    }
                    else if(courseScore[i]>=60)
                    {
                        courseGpa[i]=1.0;
                    }
                    else
                    {
                        courseGpa[i]=0;
                    }
                }
                else
                {
                    courseScore[i]=0;
                    courseGpa[i]=0;    
                }  
            }
            
            //Sort
            
            for(int p=0;p<maxC-1;p++)
            {
                for(int q=p+1;q<maxC;q++)
                {
                    if(courseScore[p]<courseScore[q]||(courseScore[p]==courseScore[q]&&courseMark[p]<courseMark[q]))
                    {
                        int tempi;
                        tempi=courseNum[p];
                        courseNum[p]=courseNum[q];
                        courseNum[q]=tempi;
                        
                        double temp;
                        temp=courseScore[p];
                        courseScore[p]=courseScore[q];
                        courseScore[q]=temp;
                        
                        temp=courseMark[p];
                        courseMark[p]=courseMark[q];
                        courseMark[q]=temp;
                        
                        temp=courseGpa[p];
                        courseGpa[p]=courseGpa[q];
                        courseGpa[q]=temp;
                    }
                    
                }
            }
            
            //Output after Sort
            for (int i=0;i<courses.size();i++)
            {
                
                Elements course=courses.get(courseNum[i]).select("td");
                
                for(int j=0;j<course.size();j++)
                {
                   Label outLabel=new Label(j,i+1+maxC+1,course.get(j).text());
                   sheet.addCell(outLabel);
                }
                
                
               
            }
            
            for (int i=0;i<courses.size()-1;i++)
            {
                Elements course=courses.get(courseNum[i]).select("td");
                Label GpaLabel=new Label(course.size(),i+1+maxC+1,Double.toString(courseGpa[i]));
                sheet.addCell(GpaLabel);
            }
            
            titleLabel=new Label(1,3+maxC+maxC,"加权平均");
            sheet.addCell(titleLabel);
            //Calculating Score and Mark
            double sumGpa=0,sumScore=0,sumMark=0;
            double avrGpa=0,avrScore=0;
            for(int k=0;k<courses.size();k++)
            {
                if(courseScore[k]!=0)
                {
                sumGpa+=courseGpa[k]*courseMark[k];
                sumScore+=courseScore[k]*courseMark[k];
                sumMark+=courseMark[k];
                }
            }
            avrGpa=sumGpa/sumMark;
            avrScore=sumScore/sumMark;
            
            Label avrLabel=new Label(scoreL,3+maxC+maxC,Double.toString(avrScore));
            sheet.addCell(avrLabel);
            avrLabel=new Label(gpaL,3+maxC+maxC,Double.toString(avrGpa));
            sheet.addCell(avrLabel);
            //Close Stream
            workbook.write();
            workbook.close();
        } catch (IOException ex) {
            Logger.getLogger(MainOutPut.class.getName()).log(Level.SEVERE, null, ex);
        } catch (WriteException ex) {
            Logger.getLogger(MainOutPut.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }
}
